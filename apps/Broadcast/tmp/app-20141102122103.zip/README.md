# Broadcast it!

App sends a broadcast to the agents with a message and the problem ID for the new alert.

### The following information is displayed:

* List of current tickets with specific tag
* Shows a notification on agents when specified group sends a broadcast.

Pull requests are welcome.

### Screenshot(s):
TBD
